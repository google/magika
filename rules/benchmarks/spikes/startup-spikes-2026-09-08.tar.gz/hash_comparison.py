# Copyright 2026 Google LLC
# SPDX-License-Identifier: Apache-2.0
"""Render the hash experiment from saved observations, without inferred verdicts."""
import argparse
import json
from pathlib import Path

from magika_rules_benchmark import corpus


def render(root, blake3_label="BLAKE3"):
    variants = ('sha256', 'blake3')
    sources = {name: root / name / 'startup/traces.json' for name in variants}
    traces = {name: json.loads(path.read_text()) for name, path in sources.items()}
    timings = {name: json.loads((root / name / 'direct/summary.json').read_text())
               for name in variants}
    stages = ['main_elapsed_ns', 'rule_pack_load_total', 'rules_payload_checksum',
              'rules_cache_identity', 'native_scratch_allocate', 'native_library_dlopen',
              'native_scan']
    rows = []
    for stage in stages:
        row = {'stage': stage}
        for name in variants:
            row[name + '_ms'] = next(s['median_ms'] for s in traces[name]['summary']
                if s['mode'] == 'mapped' and s['case'] == 'files-1-hits-100' and s['stage'] == stage)
        rows.append(row)
    process = []
    for count in (1, 10, 1000):
        row = {'files': count}
        for name in variants:
            measurement = next(m for m in timings[name]['measurements']
                               if m['tool'] == 'rules-mapped' and m['file_count'] == count)
            row[name] = {field: measurement[field] * 1000
                         for field in ('median_seconds', 'min_seconds', 'max_seconds')}
        process.append(row)
    result = {'schema': 1, 'loader': 'mapped', 'trace_case': 'files-1-hits-100',
              'source_hashes': {str(path.relative_to(root)): corpus.file_hash(path)
                                for path in [*sources.values(),
                                    *(root / name / 'direct/summary.json' for name in variants)]},
              'stages_ms': rows, 'process_ms': process}
    corpus.atomic_json(root / 'comparison.json', result)
    lines = [f'# {blake3_label} versus accelerated SHA-256', '',
             'Mapped rules on the recorded ARM64 macOS host. Stage medians from ten fresh-process '
             'traces on the same one-file rule hit. Inclusive spans overlap; do not add them.', '',
             f'| Stage | ARM SHA-256 ms | {blake3_label} ms |', '|---|---:|---:|']
    for row in rows:
        lines.append(f"| {row['stage']} | {row['sha256_ms']:.4f} | {row['blake3_ms']:.4f} |")
    lines += ['', 'Trace-disabled whole-process Hyperfine timings: twenty runs after one warmup, '
              'same saved natural workloads, warm OS caches. Ranges expose shared-host variability.', '',
              f'| Files | ARM SHA-256 median ms (min–max) | {blake3_label} median ms (min–max) |',
              '|---:|---:|---:|']
    for row in process:
        cells = [str(row['files'])]
        for name in variants:
            m = row[name]
            cells.append(f"{m['median_seconds']:.3f} ({m['min_seconds']:.3f}–{m['max_seconds']:.3f})")
        lines.append('| ' + ' | '.join(cells) + ' |')
    lines += ['', 'Both builds retain full payload/manifest hashing and native validation. '
              'They use separate pack versions and cache identities. Timed workloads and all traced '
              'classifications are checked against the saved corpus observations. This is a focused '
              'hash/startup comparison, not a new full-corpus replay. Measurements include serialized '
              'loaders and misses in the raw JSON as well.', '',
              '[SHA-256 raw traces](sha256/startup/traces.json) · '
              '[BLAKE3 raw traces](blake3/startup/traces.json) · '
              '[SHA-256 process measurements](sha256/direct/summary.json) · '
              '[BLAKE3 process measurements](blake3/direct/summary.json)', '']
    (root / 'comparison.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent / 'hash-comparison')
    parser.add_argument('--blake3-label', default='BLAKE3')
    args = parser.parse_args()
    render(args.root, args.blake3_label)
